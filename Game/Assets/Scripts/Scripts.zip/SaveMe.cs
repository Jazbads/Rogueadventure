using System.Collections;
using UnityEngine;

public class SaveMe : MonoBehaviour
{
    void Awake()
    {
        DontDestroyOnLoad(gameObject);
    }
}
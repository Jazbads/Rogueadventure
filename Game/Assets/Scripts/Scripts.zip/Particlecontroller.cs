using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Particlecontroller : MonoBehaviour
{
    private void finishanim()
    {
        Destroy(gameObject);
        
    }
}
